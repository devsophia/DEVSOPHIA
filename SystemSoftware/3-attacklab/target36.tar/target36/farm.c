/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_217()
{
    return 3351857253U;
}

void setval_144(unsigned *p)
{
    *p = 1564197720U;
}

void setval_123(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_493(unsigned x)
{
    return x + 1483989116U;
}

unsigned addval_177(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_320(unsigned x)
{
    return x + 3264239622U;
}

unsigned getval_157()
{
    return 2455264638U;
}

void setval_341(unsigned *p)
{
    *p = 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_183()
{
    return 2425408139U;
}

unsigned addval_260(unsigned x)
{
    return x + 3221801609U;
}

unsigned addval_407(unsigned x)
{
    return x + 2425405825U;
}

unsigned getval_441()
{
    return 3284238608U;
}

unsigned addval_362(unsigned x)
{
    return x + 3229931145U;
}

void setval_430(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_403(unsigned x)
{
    return x + 3286272840U;
}

unsigned getval_357()
{
    return 3376988553U;
}

void setval_435(unsigned *p)
{
    *p = 3221799305U;
}

unsigned getval_149()
{
    return 3378566793U;
}

unsigned getval_120()
{
    return 3682126473U;
}

void setval_205(unsigned *p)
{
    *p = 3468937867U;
}

unsigned addval_155(unsigned x)
{
    return x + 3281111689U;
}

void setval_108(unsigned *p)
{
    *p = 3223377545U;
}

void setval_371(unsigned *p)
{
    *p = 2425673353U;
}

unsigned getval_442()
{
    return 2430635336U;
}

void setval_147(unsigned *p)
{
    *p = 3767093898U;
}

void setval_156(unsigned *p)
{
    *p = 3523789209U;
}

void setval_472(unsigned *p)
{
    *p = 3281180297U;
}

unsigned getval_168()
{
    return 3526934913U;
}

unsigned addval_378(unsigned x)
{
    return x + 3286272264U;
}

unsigned addval_384(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_106()
{
    return 2463533519U;
}

unsigned getval_405()
{
    return 3675832713U;
}

unsigned addval_224(unsigned x)
{
    return x + 3523267209U;
}

unsigned addval_487(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_319()
{
    return 3526940169U;
}

unsigned getval_374()
{
    return 3229931149U;
}

unsigned getval_163()
{
    return 2143535497U;
}

void setval_443(unsigned *p)
{
    *p = 3286272320U;
}

unsigned getval_480()
{
    return 3674786445U;
}

void setval_450(unsigned *p)
{
    *p = 3523791497U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
